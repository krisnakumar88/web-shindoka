<div class="main-footer text-center">
    <div class="container">
        <div class="row row-sm">
            <div class="col-md-12">
                <span>Copyright © 2023 <a href="#">Shindoka</a>. Sistem Pengelolaan Keanggotaan Shindoka.</span>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\BKAD MEDAN\laravel-shindoka\resources\views/layouts/footer.blade.php ENDPATH**/ ?>